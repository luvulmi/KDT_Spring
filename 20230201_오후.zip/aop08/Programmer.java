package aop08;

public interface Programmer {
	
	String doStudying(int n) throws Exception;

} //interface
