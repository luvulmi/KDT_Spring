package aop07;

public interface Programmer {
	
	void doStudying() throws Exception;

} //interface
