package aop06;

public interface Programmer {
	
	void doStudying() throws Exception;

} //interface
