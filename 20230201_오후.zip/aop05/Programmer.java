package aop05;

public interface Programmer {
	
	String doStudying(int n, int p) throws Exception;

} //interface
