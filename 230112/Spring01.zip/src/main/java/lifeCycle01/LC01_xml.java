package lifeCycle01;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

//** Bean(객체) 의 LifeCycle
// => 객체생성 -> 사용 -> 소멸
// => 해당되는 특정시점에 자동실행 : xml, @, interface

//** Test1. xml
// => xml 에 해당 시점별 속성에 등록
//    init-method="begin" destroy-method="end" 
// => 실행순서 (생성 ........... 소멸)
// 생성자 -> init-method(생성직후 자동 호출) ..... 
//		-> 소멸(container close) -> destroy-method(자동호출) 

class LifeCycleTest {
	public LifeCycleTest() { System.out.println("~~ LifeCycleTest 생성자 ~~");}
	public void begin() {System.out.println("~~ LifeCycleTest begin() ~~");}
	public void end() {System.out.println("~~ LifeCycleTest end() ~~");}
	public void login() {System.out.println("~~ LifeCycleTest login() ~~");}
	public void list() {System.out.println("~~ LifeCycleTest list() ~~");}
} //LifeCycleTest

public class LC01_xml {

	public static void main(String[] args) {
		
		// 스프링 컨테이너 선언.
		AbstractApplicationContext sc = new
				GenericXmlApplicationContext("lifeCycle01/lc01.xml");
		LifeCycleTest lc = (LifeCycleTest)sc.getBean("lc"); // String으로 id 넣어주기. 타입이 안맞으므로 형변환.
		lc.login();
		lc.list();
		sc.close(); // 컨테이너 쓸 일 없으면 닫아주기.
	

	}//main

}//class
