package controllerM;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.MemberService;
import vo.MemberVO;
 
// ** Member Join
 
@WebServlet("/mupdate")
public class C06_mUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public C06_mUpdate() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 1) 요청분석
    	// => Service 준비
		// => request, 한글처리
		//    한글처리 (utf-8 이면 get 방식은 안해도 되지만, post 방식은 반드시 해야함_getParameter 하기전에)
		// 	  Parameter -> vo 에 set
		request.setCharacterEncoding("UTF-8");
		//String id=request.getParameter("id");
		String password=request.getParameter("password");
		String name=request.getParameter("name");
		int age=Integer.parseInt(request.getParameter("age"));
		int jno=Integer.parseInt(request.getParameter("jno")) ;
		String info=request.getParameter("info");
		double point=Double.parseDouble(request.getParameter("point"));
		String birthday=request.getParameter("birthday");
				
		MemberService service = new MemberService();
		MemberVO vo = new MemberVO();
		vo.setId(request.getParameter("id"));
		vo.setPassword(password);
		vo.setName(name);
		vo.setAge(age);
		vo.setJno(jno);
		vo.setInfo(info);
		vo.setPoint(point);
		vo.setBirthday(birthday);
		 
		request.setAttribute("apple",vo);
		// => Update 성공/실패 모두 출력시 필요하므로
		
		// 2) Service처리 (update)
		// => 성공 : 내정보 표시 -> memberDetail.jsp
		// 			-> "/mdetail" 요청 또는 apple 을 setAttribute 하고 jsp로 forward
		//			-> 이름을 수정한 경우에는 session에 보관된 loginName 도 변경시켜야함. 
		// => 실패 : 친절하게 안내하고 재수정 유도 -> updateForm.jsp
		String uri="member/memberDetail.jsp" ;
		
		if ( service.update(vo)>0 ) {
			request.setAttribute("message", "~~ 회원정보 수정 성공 ~~");
			if ( request.getSession().getAttribute("loginName")!=null )  {
				request.getSession().setAttribute("loginName", vo.getName());
			}
		}else {
			uri="member/updateForm.jsp" ;
			request.setAttribute("message", "~~ 회원정보 수정 실패, 다시 하세요 ~~");
		}
		// 3) View 로 Forward
		request.getRequestDispatcher(uri).forward(request, response);
		 
	} //doGet

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
} //class
